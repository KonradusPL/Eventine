package com.racjonalnytraktor.findme3.ui.base

/**
 * Created by Admin on 2018-04-29.
 */
class BaseDialog<V: MvpView>: BaseFragment<V>() {

}