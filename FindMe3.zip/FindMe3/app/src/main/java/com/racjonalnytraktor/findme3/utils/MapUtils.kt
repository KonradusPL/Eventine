package com.racjonalnytraktor.findme3.utils

object MapUtils {

    data class Tile(val x: Int, val y: Int)

    val tiles = arrayListOf(
            Tile(292739,172683),
            Tile(292740,172683),
            Tile(292739,172684),
            Tile(292740,172684),
            Tile(292739,172685),
            Tile(292740,172685),
            Tile(292739,172686),
            Tile(292740,172686)
    )
}