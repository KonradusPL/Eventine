package com.racjonalnytraktor.findme3.data.network.model.register

data class RegisterFbRequest(val facebookId: String, val fullName: String)