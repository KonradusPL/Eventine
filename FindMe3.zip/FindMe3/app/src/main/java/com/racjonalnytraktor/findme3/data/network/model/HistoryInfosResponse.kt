package com.racjonalnytraktor.findme3.data.network.model

import com.racjonalnytraktor.findme3.data.network.model.info.Info

class HistoryInfosResponse(val info: ArrayList<Info>)