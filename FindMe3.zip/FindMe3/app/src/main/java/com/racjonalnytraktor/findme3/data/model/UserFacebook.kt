package com.racjonalnytraktor.findme3.data.model


data class UserFacebook(val fullName: String, val id: String)