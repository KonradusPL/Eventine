package com.racjonalnytraktor.findme3.data.network.model

data class JoinRequest(val groupName: String)