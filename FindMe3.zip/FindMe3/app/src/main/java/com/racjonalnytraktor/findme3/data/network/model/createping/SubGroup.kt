package com.racjonalnytraktor.findme3.data.network.model.createping

data class SubGroup(val name: String)