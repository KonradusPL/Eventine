package com.racjonalnytraktor.findme3.data.network.model.login


data class LoginRequest(val email: String, val password: String)