package com.racjonalnytraktor.findme3.data.model

data class Person(val fullName: String, val id: String, var pictureUri: String = "")