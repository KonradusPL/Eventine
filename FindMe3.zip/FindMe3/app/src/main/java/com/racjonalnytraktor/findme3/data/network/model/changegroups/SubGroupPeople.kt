package com.racjonalnytraktor.findme3.data.network.model.changegroups

data class SubGroupPeople(val people: ArrayList<UserInSubGroup>)