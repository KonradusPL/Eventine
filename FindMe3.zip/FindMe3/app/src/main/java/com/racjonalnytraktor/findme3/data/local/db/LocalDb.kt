package com.racjonalnytraktor.findme3.data.local.db

import com.racjonalnytraktor.findme3.data.local.Prefs


interface LocalDb: Prefs {
}