package com.racjonalnytraktor.findme3.data.model.new

data class Relative(
        var id: String = "",
        var name: String = ""
)