package com.racjonalnytraktor.findme3.data.model

data class Task(val taskName: String,val boss: String, val groupImageUri: String)