package com.racjonalnytraktor.findme3.data.network.model

/**
 * Created by Admin on 2018-06-03.
 */
data class ChangeSubGroupRequest(val changingId: String, val groupId: String, val changedSubgroup: String)