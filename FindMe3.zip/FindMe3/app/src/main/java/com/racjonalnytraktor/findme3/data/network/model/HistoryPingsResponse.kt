package com.racjonalnytraktor.findme3.data.network.model

import com.racjonalnytraktor.findme3.data.network.model.createping.Ping

/**
 * Created by Admin on 2018-06-03.
 */
data class HistoryPingsResponse(val pings: ArrayList<Ping>)