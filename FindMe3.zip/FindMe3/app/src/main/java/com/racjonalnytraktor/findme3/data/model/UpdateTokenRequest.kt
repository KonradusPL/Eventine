package com.racjonalnytraktor.findme3.data.model

data class UpdateTokenRequest(val notifToken: String)