package com.racjonalnytraktor.findme3.data.network

import com.racjonalnytraktor.findme3.data.network.model.UserSimple

data class MembersResponse(var people: ArrayList<UserSimple>)