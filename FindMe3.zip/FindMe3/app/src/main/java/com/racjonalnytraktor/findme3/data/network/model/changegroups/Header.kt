package com.racjonalnytraktor.findme3.data.network.model.changegroups

data class Header(val group: String): Typed()