package com.racjonalnytraktor.findme3.data.network.model.pings

import com.racjonalnytraktor.findme3.data.network.model.createping.Ping

data class PingsResponse(val pings: ArrayList<Ping>)