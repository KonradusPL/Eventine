package com.racjonalnytraktor.findme3.data.model.map

data class ZoneUpdate(var name: String = "", var usersCount: Int = 0)