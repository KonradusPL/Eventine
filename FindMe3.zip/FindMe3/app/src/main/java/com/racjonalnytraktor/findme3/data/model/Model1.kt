package com.racjonalnytraktor.findme3.data.model

data class Model1(var title: String = "",
                  var message: String = "",
                  var date: String = "",
                  var id: String = "",
                  var status: String = "")