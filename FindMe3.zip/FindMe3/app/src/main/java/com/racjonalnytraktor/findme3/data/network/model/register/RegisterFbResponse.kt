package com.racjonalnytraktor.findme3.data.network.model.register

/**
 * Created by Admin on 2018-05-27.
 */
class RegisterFbResponse(var success: String = "", var token: String = "", var fbId: String ="")