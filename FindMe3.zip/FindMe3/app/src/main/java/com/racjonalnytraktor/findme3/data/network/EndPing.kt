package com.racjonalnytraktor.findme3.data.network

/**
 * Created by Admin on 2018-06-06.
 */
data class EndPing(val pingId: String)