package com.racjonalnytraktor.findme3.data.model

data class GroupWithUsers(val group: Group, val users: ArrayList<Person>)