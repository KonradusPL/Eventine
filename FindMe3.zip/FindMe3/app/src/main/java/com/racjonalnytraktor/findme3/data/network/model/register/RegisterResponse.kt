package com.racjonalnytraktor.findme3.data.network.model.register

/**
 * Created by Admin on 2018-05-29.
 */
data class RegisterResponse(val succes: String, val token: String)