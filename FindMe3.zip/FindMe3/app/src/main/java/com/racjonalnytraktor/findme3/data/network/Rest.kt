package com.racjonalnytraktor.findme3.data.network

interface Rest {


}