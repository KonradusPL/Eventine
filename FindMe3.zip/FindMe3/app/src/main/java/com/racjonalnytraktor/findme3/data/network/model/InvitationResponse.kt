package com.racjonalnytraktor.findme3.data.network.model

import com.racjonalnytraktor.findme3.data.model.Invitation

data class InvitationResponse(val invitations: List<Invitation>)