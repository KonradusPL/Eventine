package com.racjonalnytraktor.findme3.data.model

data class ActionsResponse(var actions: ArrayList<Action> = ArrayList())