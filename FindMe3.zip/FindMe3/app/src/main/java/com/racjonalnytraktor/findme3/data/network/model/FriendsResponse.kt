package com.racjonalnytraktor.findme3.data.network.model

import com.racjonalnytraktor.findme3.data.model.Person
import com.racjonalnytraktor.findme3.data.model.User

data class FriendsResponse(val users: ArrayList<User>)