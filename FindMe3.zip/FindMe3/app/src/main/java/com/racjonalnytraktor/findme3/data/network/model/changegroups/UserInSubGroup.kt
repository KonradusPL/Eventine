package com.racjonalnytraktor.findme3.data.network.model.changegroups

data class UserInSubGroup(val id: String, val name: String, val subgroup: String): Typed()