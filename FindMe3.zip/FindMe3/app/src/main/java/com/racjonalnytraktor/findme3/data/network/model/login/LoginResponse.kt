package com.racjonalnytraktor.findme3.data.network.model.login

class LoginResponse(val token: String,val fullName: String, val isPartner: Boolean)