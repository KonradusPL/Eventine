package com.racjonalnytraktor.findme3.data.network.model

data class UserSimple(var name: String = "",
                      var id: String = "",
                      var subgroup: String = "",
                        var location: String = "")